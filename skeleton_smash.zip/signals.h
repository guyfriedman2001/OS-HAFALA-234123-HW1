#ifndef SMASH__SIGNALS_H_
#define SMASH__SIGNALS_H_

void ctrlCHandler(int sig_num);

#endif //SMASH__SIGNALS_H_
