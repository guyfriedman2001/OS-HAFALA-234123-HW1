//
// Created by Guy Friedman on 06/05/2025.
//

#ifndef TEMP_RESTORE_H
#define TEMP_RESTORE_H

#if 0
class Temp_Restore {
public:
  Temp_Restore();
  ~Temp_Restore();
};

#endif

#endif //TEMP_RESTORE_H
